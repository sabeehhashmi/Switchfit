<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TemporaryCard extends Model
{
    protected $table='temporary_cards';
}
