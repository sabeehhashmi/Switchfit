<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FavouriteTrainer extends Model
{
    protected $table='favorit_trainers';
}
