<div class="alert text-center" role="alert" style="border: none; background-color: white;padding-top: 150px;padding-bottom: 150px;">
    <b style="color: #60677073;font-size: 25px;">{{isset($message) ?$message: 'Not Found'}}</b>
</div>
