<!-- content -->
<footer class="footer text-center">
    <span class="text-center">Copyright © 2020 SwitchFit, All Rights Reserved</span>
</footer>

