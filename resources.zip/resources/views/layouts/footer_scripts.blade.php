<!-- jQuery  -->
<script src="{{asset('assets/js/popper.min.js')}}"></script>
<script src="{{asset('assets/js/bootstrap.min.js')}}"></script>
<script src="{{asset('assets/js/metisMenu.min.js')}}"></script>
<script src="{{asset('assets/js/waves.js')}}"></script>
<script src="{{asset('assets/js/jquery.slimscroll.js')}}"></script>
<!-- Flot chart -->
{{--<script src="{{asset('assets/plugins/flot-chart/jquery.flot.min.js')}}"></script>--}}
{{--<script src="{{asset('assets/plugins/flot-chart/jquery.flot.time.js')}}"></script>--}}
{{--<script src="{{asset('assets/plugins/flot-chart/jquery.flot.tooltip.min.js')}}"></script>--}}
{{--<script src="{{asset('assets/plugins/flot-chart/jquery.flot.resize.js')}}"></script>--}}
{{--<script src="{{asset('assets/plugins/flot-chart/jquery.flot.pie.js')}}"></script>--}}
{{--<script src="{{asset('assets/plugins/flot-chart/jquery.flot.crosshair.js')}}"></script>--}}
{{--<script src="{{asset('assets/plugins/flot-chart/curvedLines.js')}}"></script>--}}
{{--<script src="{{asset('assets/plugins/flot-chart/jquery.flot.axislabels.js')}}"></script>--}}
<script src="{{asset('assets/plugins/jquery-knob/jquery.knob.js')}}"></script>
<!-- Dashboard Init -->
{{--<script src="{{asset('assets/pages/jquery.dashboard.init.js')}}"></script>--}}


<!-- Bootstrap fileupload js -->
<script src="{{asset('assets/plugins/bootstrap-fileupload/bootstrap-fileupload.js')}}"></script>

<!-- Required datatable js -->
<script src="{{asset('assets/plugins/datatables/jquery.dataTables.min.js')}}"></script>
<script src="{{asset('assets/plugins/datatables/dataTables.bootstrap4.min.js')}}"></script>
<script src="{{asset('assets/plugins/switchery/switchery.min.js')}}"></script>

<!-- App js -->
<script src="{{asset('assets/js/jquery.core.js')}}"></script>
<script src="{{asset('assets/js/jquery.app.js')}}"></script>

<script src="{{asset('assets/js/mycustom.js')}}"></script>


@yield('script')
